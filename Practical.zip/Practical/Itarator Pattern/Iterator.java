interface Iterator {
    boolean hasNext();
    MenuItem next();
}
