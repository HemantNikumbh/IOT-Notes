package OBSERVER;

public interface DisplayElement
{
	public void display();

}
